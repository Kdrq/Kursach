from django.shortcuts import render, get_object_or_404, redirect
from django.utils import timezone
from .models import Themes, Comments
from .forms import ThemesForm, CommentsForm
from django.contrib import auth
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator


def themes_list(request, page_number=1):
    themes = Themes.objects.filter(published_date__lte=timezone.now()).order_by('-pk')
    current_page = Paginator(themes, 3)
    return render(request, 'forum/themes_list.html', {'themes': current_page.page(page_number)})

def theme_discussion(request, pk, page_number=1):
    theme = get_object_or_404(Themes, pk=pk)
    comments = Comments.objects.filter(theme=theme).order_by('-pk')
    current_page = Paginator(comments, 3)
    return render(request, 'forum/theme_discussion.html', {'theme': theme, 'comments': current_page.page(page_number)})

@login_required
def theme_new(request):
    if request.method == "POST":
        form = ThemesForm(request.POST)
        if form.is_valid():
            theme = form.save(commit=False)
            theme.author = request.user
            theme.published_date = timezone.now()
            theme.save()
            return redirect('themes_list')
    else:
        form = ThemesForm()
    return render(request, 'forum/theme_new.html', {'form': form})

@login_required
def theme_edit(request, pk):
    theme = get_object_or_404(Themes, pk=pk)
    if request.method == "POST":
        form = ThemesForm(request.POST, instance=theme)
        if form.is_valid():
            theme = form.save(commit=False)
            theme.author = request.user
            theme.published_date = timezone.now()
            theme.save()
            return redirect('theme_discussion', pk=theme.pk)
    else:
        form = ThemesForm(instance=theme)
    return render(request, 'forum/theme_edit.html', {'form': form, 'theme': theme})

@login_required
def theme_remove(request, pk):
    theme = get_object_or_404(Themes, pk=pk)
    theme.delete()
    return redirect('themes_list')


@login_required
def comment_add(request, pk):
    theme = get_object_or_404(Themes, pk=pk)
    if request.method == "POST":
        form = CommentsForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.theme = theme
            comment.author = request.user
            comment.published_date = timezone.now()
            comment.save()
            return redirect('theme_discussion', pk=theme.pk)
    else:
        form = CommentsForm()
    return render(request, 'forum/comment_new.html', {'form': form, 'theme': theme})

@login_required
def comment_edit(request, pk):
    comment = get_object_or_404(Comments, pk=pk)
    if request.method == "POST":
        form = CommentsForm(request.POST, instance=comment)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.author = request.user
            comment.published_date = timezone.now()
            comment.save()
            return redirect('theme_discussion', pk=comment.theme.pk)
    else:
        form = CommentsForm(instance=comment)
    return render(request, 'forum/comment_edit.html', {'form': form, 'theme': comment.theme, 'comment': comment})

@login_required
def comment_remove(request, pk):
    comment = get_object_or_404(Comments, pk=pk)
    comment.delete()
    return redirect('theme_discussion', pk=comment.theme.pk)

@login_required
def like(request, pk):
    theme = get_object_or_404(Themes, pk=pk)
    theme.likes += 1
    theme.save()
    return redirect('theme_discussion', pk=theme.pk)

@login_required
def dislike(request, pk):
    theme = get_object_or_404(Themes, pk=pk)
    theme.dislikes += 1
    theme.save()
    return redirect('theme_discussion', pk=theme.pk)

def registration(request):
    args = {}
    if request.POST:
        username = request.POST.get('username', '')
        email = request.POST.get('email', '')
        password = request.POST.get('password', '')
        passwordagain = request.POST.get('passwordagain', '')
        user = User.objects.filter(username=username).exists()
        if user:
            args['reg_error'] = "Такой пользователь уже существует"
            return render(request, 'registration/registration.html', args)
        if password != passwordagain:
            args['reg_error'] = "Неверный пароль"
            return render(request, 'registration/registration.html', args)
        elif len(password) < 8:
            args['reg_error'] = "Пароль должен состоять не менее чем из 8 символов"
            return render(request, 'registration/registration.html', args)
        else:
            new_user = User.objects.create_user(username=username, email=email, password=passwordagain)
            new_user.save()
            auth.login(request, new_user)
            return redirect('/')
    else:
        return render(request, 'registration/registration.html', args)

def login(request):
    args = {}
    if request.POST:
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect('/')
        else:
            args['login_error'] = "Неверное имя пользователя или пароль"
            return render(request, 'forum/login.html', args)
    else:
        return render(request, 'forum/login.html', args)

def logout(request):
    auth.logout(request)
    return redirect('/')