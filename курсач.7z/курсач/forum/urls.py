from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^page/(\d+)/$', views.themes_list, name='themes_list'),
    url(r'^theme/(?P<pk>[0-9]+)/page/(?P<page_number>\d+)/$', views.theme_discussion, name='theme_discussion'),
    url(r'^$', views.themes_list, name='themes_list'),
    url(r'^theme/(?P<pk>[0-9]+)/$', views.theme_discussion, name='theme_discussion'),
    url(r'^theme/new/$', views.theme_new, name='theme_new'),
    url(r'^theme/(?P<pk>[0-9]+)/edit/$', views.theme_edit, name='theme_edit'),
    url(r'^theme/(?P<pk>\d+)/remove/$', views.theme_remove, name='theme_remove'),
    url(r'^theme/(?P<pk>\d+)/comment/$', views.comment_add, name='comment_add'),
    url(r'^comment/(?P<pk>\d+)/edit/$', views.comment_edit, name='comment_edit'),
    url(r'^comment/(?P<pk>\d+)/comment_remove/$', views.comment_remove, name='comment_remove'),
    url(r'^registration/$', views.registration, name="registration"),
    url(r'^login/', views.login, name="login"),
    url(r'^logout/', views.logout, name="logout"),
    url(r'^theme/(?P<pk>\d+)/like/$', views.like, name='like'),
    url(r'^theme/(?P<pk>\d+)/dislike/$', views.dislike, name='dislike'),
]