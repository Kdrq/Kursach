from django import forms
from .models import Themes, Comments

class ThemesForm(forms.ModelForm):
    class Meta:
        model = Themes
        fields = ('title', 'text')


class CommentsForm(forms.ModelForm):
    class Meta:
        model = Comments
        fields = ('text',)


