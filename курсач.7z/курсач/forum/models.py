from django.db import models
from django.utils import timezone

class Themes(models.Model):
    author = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    title = models.CharField(max_length=200, verbose_name="Название")
    text = models.TextField(verbose_name="Описание темы")
    created_date = models.DateTimeField(default=timezone.now)
    published_date = models.DateTimeField(blank=True, null=True)
    likes = models.IntegerField(default=0)
    dislikes = models.IntegerField(default=0)

    def publish(self):
        self.published_date = timezone.now()
        self.save()

    def __str__(self):
        return self.title

class Comments(models.Model):
    author = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    theme = models.ForeignKey(Themes, related_name='comments', on_delete=models.CASCADE)
    text = models.TextField(verbose_name="Текст комментария")
    created_date = models.DateTimeField(default=timezone.now)
    published_date = models.DateTimeField(blank=True, null=True)

    def write(self):
        self.published_date = timezone.now()
        self.save()

    def __str__(self):
        return self.text
