from django.contrib import admin
from .models import Themes, Comments

admin.site.register(Themes)
admin.site.register(Comments)
